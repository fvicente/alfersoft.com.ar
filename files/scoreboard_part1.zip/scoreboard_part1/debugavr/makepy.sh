pyrcc4 res/debugavr.qrc >debugavr_rc.py
pyuic4 res/debugavr.ui  >debugavr_ui.py
pyuic4 res/mmanager.ui  >>debugavr_ui.py
pyuic4 res/addmem.ui    >>debugavr_ui.py
pyuic4 res/changeval.ui >>debugavr_ui.py
pyuic4 res/input.ui     >>debugavr_ui.py
